// AIAdvisor.java
// Calls the Claude AI API from pure Java using HttpURLConnection (built into JDK 8+).
// No external libraries needed — just standard Java networking classes.
//
// HOW IT WORKS:
// 1. Build a JSON request body as a plain String
// 2. Send it via HTTP POST to the Anthropic API endpoint
// 3. Read the response and extract the advisory text
//
// NOTE: The project works WITHOUT an API key (graceful fallback mode).
// To activate AI: replace "YOUR_API_KEY_HERE" with a real key from console.anthropic.com

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AIAdvisor {

    // API configuration constants
    private static final String API_URL   = "https://api.anthropic.com/v1/messages";
    private static final String API_KEY   = "YOUR_API_KEY_HERE"; // Replace with real key to activate
    private static final String MODEL     = "claude-sonnet-4-6";
    private static final boolean AI_ENABLED = !API_KEY.equals("YOUR_API_KEY_HERE");

    // --- PUBLIC: getAdvisory() ---
    // Takes a RouteResult and returns a natural-language travel advisory string.
    public String getAdvisory(RouteResult result) {

        // If no API key is configured, return a helpful placeholder
        if (!AI_ENABLED) {
            return getFallbackAdvisory(result);
        }

        try {
            return callClaudeAPI(result);
        } catch (Exception e) {
            // If the API call fails for any reason, fall back gracefully
            return "[AI Advisory unavailable: " + e.getMessage() + "]\n" + getFallbackAdvisory(result);
        }
    }

    // --- PRIVATE: callClaudeAPI() ---
    // Builds the HTTP request and parses the response — pure Java networking.
    private String callClaudeAPI(RouteResult result) throws Exception {

        // Build the prompt we send to Claude
        String prompt = "You are a smart urban transit advisor. A commuter is taking this route: "
                + result.getPathAsString()
                + ". Total travel time: " + result.getTotalTime() + " minutes with "
                + result.getStopCount() + " intermediate stops. "
                + "Give a concise, helpful travel advisory in 3 sentences maximum. "
                + "Include one practical tip about the journey. Be friendly and direct.";

        // Build the JSON request body as a String
        // We manually construct JSON to avoid needing any external library
        String requestBody = "{"
                + "\"model\": \"" + MODEL + "\","
                + "\"max_tokens\": 200,"
                + "\"messages\": [{\"role\": \"user\", \"content\": \"" + prompt + "\"}]"
                + "}";

        // --- SET UP HTTP CONNECTION ---
        URL url = new URL(API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", API_KEY);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true); // Allow sending a request body
        conn.setConnectTimeout(10000); // 10 second timeout
        conn.setReadTimeout(15000);    // 15 second read timeout

        // --- SEND REQUEST ---
        OutputStream os = conn.getOutputStream();
        os.write(requestBody.getBytes("UTF-8"));
        os.close();

        // --- READ RESPONSE ---
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            response.append(line);
        }
        br.close();

        // --- EXTRACT TEXT FROM JSON RESPONSE ---
        // We parse the JSON manually using String operations
        // The response looks like: {...,"content":[{"type":"text","text":"...advisory..."}],...}
        String json = response.toString();
        String marker = "\"text\":\"";
        int start = json.indexOf(marker);
        if (start == -1) return "Could not parse AI response.";
        start += marker.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return "Could not parse AI response.";

        // Clean up escaped characters from JSON string
        return json.substring(start, end)
                .replace("\\n", "\n")
                .replace("\\\"", "\"");
    }

    // --- PRIVATE: getFallbackAdvisory() ---
    // Rule-based advisory when AI is not available.
    // Demonstrates that the app is useful even without the AI layer.
    private String getFallbackAdvisory(RouteResult result) {
        StringBuilder advisory = new StringBuilder();
        advisory.append("  📋 Travel Advisory (Standard Mode):\n");

        if (result.getTotalTime() <= 20) {
            advisory.append("  ✔ Short journey — direct and efficient route.\n");
        } else if (result.getTotalTime() <= 40) {
            advisory.append("  ✔ Moderate journey — allow extra 10 minutes during peak hours.\n");
        } else {
            advisory.append("  ⚠ Long journey — consider traveling off-peak (before 8AM or after 7PM).\n");
        }

        if (result.getStopCount() == 0) {
            advisory.append("  ✔ Direct route — no transfers needed.\n");
        } else if (result.getStopCount() == 1) {
            advisory.append("  ✔ One transfer required — allow 5 minutes at the interchange.\n");
        } else {
            advisory.append("  ⚠ Multiple transfers — keep your journey plan handy.\n");
        }

        advisory.append("  💡 Tip: Validate your ticket at every boarding point.\n");
        advisory.append("\n  [To activate AI advisories: add your API key in AIAdvisor.java]");

        return advisory.toString();
    }
}
