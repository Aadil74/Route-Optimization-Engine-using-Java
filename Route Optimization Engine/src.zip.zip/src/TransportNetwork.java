// TransportNetwork.java
// Manages ALL stations and the connections between them.
// The network is stored as a 2D ADJACENCY MATRIX — a core CS data structure.
// matrix[i][j] = travel time in minutes from station i to station j.
// matrix[i][j] = 0 means NO direct connection exists.

public class TransportNetwork {

    // Maximum number of stations our network can hold
    public static final int MAX_STATIONS = 15;

    // The adjacency matrix — a 2D array of travel times
    // This is the GRAPH that Dijkstra's algorithm will search
    private int[][] matrix;

    // Array of Station objects — parallel to the matrix rows/columns
    private Station[] stations;
    private int stationCount;

    // --- CONSTRUCTOR ---
    public TransportNetwork() {
        matrix       = new int[MAX_STATIONS][MAX_STATIONS]; // All zeroes by default = no connections
        stations     = new Station[MAX_STATIONS];
        stationCount = 0;
        loadNetwork(); // Pre-load all stations and routes
    }

    // --- PRIVATE: loadNetwork() ---
    // Hardcoded fictional-but-realistic city network.
    // Fictional keeps the demo clean and fully under our control.
    private void loadNetwork() {

        // --- ADD STATIONS ---
        // Each station gets a unique ID matching its array index (0-based)
        addStation(new Station(0,  "Central Terminal",       "TRAIN", "CENTRAL"));
        addStation(new Station(1,  "Riverside Bus Depot",    "BUS",   "CENTRAL"));
        addStation(new Station(2,  "Northgate Metro",        "METRO", "NORTH"  ));
        addStation(new Station(3,  "University Stop",        "BUS",   "NORTH"  ));
        addStation(new Station(4,  "Eastwood Junction",      "TRAIN", "EAST"   ));
        addStation(new Station(5,  "Southpark Terminal",     "BUS",   "SOUTH"  ));
        addStation(new Station(6,  "Westfield Metro",        "METRO", "WEST"   ));
        addStation(new Station(7,  "Airport Express",        "TRAIN", "EAST"   ));
        addStation(new Station(8,  "Harbour Bus Stop",       "BUS",   "SOUTH"  ));
        addStation(new Station(9,  "Tech Park Station",      "METRO", "WEST"   ));
        addStation(new Station(10, "Old Town Crossing",      "BUS",   "CENTRAL"));
        addStation(new Station(11, "Stadium Metro",          "METRO", "NORTH"  ));
        addStation(new Station(12, "Industrial Zone Stop",   "BUS",   "EAST"   ));

        // --- ADD ROUTES (bidirectional connections) ---
        // addRoute(fromId, toId, travelTimeInMinutes)
        // Both directions are set — you can travel either way on each link.
        addRoute(0,  1,  8);   // Central Terminal ↔ Riverside Bus Depot
        addRoute(0,  2,  15);  // Central Terminal ↔ Northgate Metro
        addRoute(0,  4,  20);  // Central Terminal ↔ Eastwood Junction
        addRoute(0,  10, 10);  // Central Terminal ↔ Old Town Crossing
        addRoute(1,  3,  12);  // Riverside ↔ University Stop
        addRoute(1,  5,  18);  // Riverside ↔ Southpark Terminal
        addRoute(1,  10, 7);   // Riverside ↔ Old Town Crossing
        addRoute(2,  3,  9);   // Northgate Metro ↔ University Stop
        addRoute(2,  6,  14);  // Northgate Metro ↔ Westfield Metro
        addRoute(2,  11, 11);  // Northgate Metro ↔ Stadium Metro
        addRoute(3,  11, 16);  // University Stop ↔ Stadium Metro
        addRoute(4,  7,  22);  // Eastwood Junction ↔ Airport Express
        addRoute(4,  12, 13);  // Eastwood Junction ↔ Industrial Zone
        addRoute(5,  8,  10);  // Southpark Terminal ↔ Harbour Bus Stop
        addRoute(5,  6,  19);  // Southpark Terminal ↔ Westfield Metro
        addRoute(6,  9,  8);   // Westfield Metro ↔ Tech Park Station
        addRoute(7,  12, 17);  // Airport Express ↔ Industrial Zone
        addRoute(8,  9,  21);  // Harbour Bus Stop ↔ Tech Park Station
        addRoute(9,  10, 14);  // Tech Park Station ↔ Old Town Crossing
        addRoute(10, 11, 12);  // Old Town Crossing ↔ Stadium Metro
    }

    // --- PRIVATE: addStation() ---
    private void addStation(Station s) {
        if (stationCount < MAX_STATIONS) {
            stations[stationCount] = s;
            stationCount++;
        }
    }

    // --- PUBLIC: addRoute() ---
    // Sets travel time in BOTH directions (undirected graph)
    public void addRoute(int fromId, int toId, int travelTime) {
        matrix[fromId][toId] = travelTime; // Direction A → B
        matrix[toId][fromId] = travelTime; // Direction B → A (same time both ways)
    }

    // --- PUBLIC: getTravelTime() ---
    // Returns the direct travel time between two stations.
    // Returns 0 if no direct connection exists.
    public int getTravelTime(int fromId, int toId) {
        return matrix[fromId][toId];
    }

    // --- PUBLIC: getStation() ---
    public Station getStation(int id) {
        if (id >= 0 && id < stationCount) {
            return stations[id];
        }
        return null;
    }

    // --- PUBLIC: getStationCount() ---
    public int getStationCount() {
        return stationCount;
    }

    // --- PUBLIC: findStationByName() ---
    // Case-insensitive partial name search.
    // Returns the first match found, or null if nothing matches.
    public Station findStationByName(String query) {
        String lowerQuery = query.toLowerCase().trim();
        for (int i = 0; i < stationCount; i++) {
            if (stations[i].getName().toLowerCase().contains(lowerQuery)) {
                return stations[i];
            }
        }
        return null;
    }

    // --- PUBLIC: displayAllStations() ---
    // Prints the full station list so users can pick their origin/destination.
    public void displayAllStations() {
        System.out.println("\n  ╔══════════════════════════════════════════════════════════╗");
        System.out.println("  ║                  STATION DIRECTORY                       ║");
        System.out.println("  ╠══════════════════════════════════════════════════════════╣");
        for (int i = 0; i < stationCount; i++) {
            System.out.println(stations[i]); // Calls Station.toString()
        }
        System.out.println("  ╚══════════════════════════════════════════════════════════╝");
    }

    // --- PUBLIC: displayNetworkStats() ---
    // Counts and displays how many direct connections each station has.
    // Also flags any station with only 1 connection (isolated risk alert).
    public void displayNetworkStats() {
        System.out.println("\n  ╔══════════════════════════════════════════════════════════╗");
        System.out.println("  ║               NETWORK CONNECTIVITY REPORT                ║");
        System.out.println("  ╠══════════════════════════════════════════════════════════╣");

        for (int i = 0; i < stationCount; i++) {
            int connections = 0;
            // Count non-zero entries in row i of the matrix
            for (int j = 0; j < stationCount; j++) {
                if (matrix[i][j] > 0) connections++;
            }
            String alert = (connections <= 1) ? "  ⚠ LOW CONNECTIVITY" : "";
            System.out.printf("  ║  %-28s | %d connection(s)%-18s║%n",
                    stations[i].getName(), connections, alert);
        }
        System.out.println("  ╚══════════════════════════════════════════════════════════╝");
    }
}
